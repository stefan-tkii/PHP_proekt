

<?php

class review
{
    public function __construct()
    {
        
    }

    public $Id;
    public $content;
    public $userId;
    public $gameId;
}

?>