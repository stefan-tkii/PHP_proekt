<?php

class user
{
    public function __construct()
    {
        
    }

    public $Id;
    public $firstName;
    public $lastName;
    public $email;
    public $username;
    public $password;
    public $birthDate;
}




?>