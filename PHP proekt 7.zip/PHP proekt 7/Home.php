<?php
?>

<!DOCTYPE html>

    <head>
        
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="home.css"/>
    </head>
    <body class="boddie">
        <div class="topnav">
            <ul>
                <li><a href="Login.php">Login</a></li>
                <li><a href="Register.php">Register </a></li>
                <li style="float:right"><a class="active" href="#about">About</a></li>
        </ul>
        </div>
        <div class="container">
            <h2 class="para">Welcome to #Site name#</h2><br>
            <p class="para">
                #Site name# is dedicated to help gamers world wide to express their opinions about games.
                Our clients can register for free and post about games or just read other client's posts
                and comment their opinions on those games. Also they can vote all the games so that we can chose our favorite
                game of the year every year.
            </p><br><br><br>
            <div class="polaroid rotate_right">
                <img src="Assets/home_image_1.jpg" width="300" height="300">
            </div>

            <div class="polaroid rotate_left">
                <img src="Assets/home_image_2.jpg" width="300" height="300">
            </div>
            <div class="polaroid rotate_right">
                <img src="Assets/home_image_3.jpeg" width="300" height="300">
            </div>
        </div>
    </body>

