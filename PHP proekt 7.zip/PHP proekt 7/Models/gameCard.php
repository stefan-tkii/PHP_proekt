
<?php

class gameCard
{
    public function __construct()
    {
        
    }
    public $Id;
    public $name;
    public $compNames;
    public $platforms;
    public $releaseDate;
  /*dodaj za image!*/ 
}


?>