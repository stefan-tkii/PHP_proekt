<?php

class apache_child_terminate
{
    public function __construct()
    {
        
    }

    public $Id;
    public $firstName;
    public $lastName;
    public $email;
    public $username;
    public $password;
    public $birthDate;
    public $isAdmin;
}




?>