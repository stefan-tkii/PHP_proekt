
<?php

class game
{
    public function __construct()
    {
        
    }

    public $Id;
    public $name;
    public $compNames;
    public $platforms;
    public $releaseDate;
    public $adminId;
}


?>