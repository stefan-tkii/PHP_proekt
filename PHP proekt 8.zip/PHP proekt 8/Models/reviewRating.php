
<?php

class reviewRating
{
    public function __construct()
    {
        
    }

    public $Id;
    public $helpful;
    public $userId;
    public $reviewId;
}

?>