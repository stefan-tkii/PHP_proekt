<?php

class genre
{
    public function __construct()
    {
        
    }

    public $Id;
    public $type;
}

?>