

<?php

class gameRating
{
    public function __construct()
    {
        
    }
    public $Id;
    public $rating;
    public $comment;
    public $userId;
    public $gameId;
}

?>