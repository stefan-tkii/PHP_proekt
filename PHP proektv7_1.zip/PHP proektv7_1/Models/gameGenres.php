<?php

class gameGenres
{
    public function __construct()
    {
        
    }
    public $Id;
    public $gameId;
    public $genreId;
}


?>