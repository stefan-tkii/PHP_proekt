

<?php

class userGameGenres
{
    public function __construct()
    {
        
    }

    public $Id;
    public $userGameId;
    public $genreId;
}

?>